# Road-Turn-Detections > 2023-09-30 3:18pm
https://universe.roboflow.com/nust-fjqyh/road-turn-detections

Provided by a Roboflow user
License: CC BY 4.0

